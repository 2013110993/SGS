#ifndef ACADEMICPROGRAM_H
#define ACADEMICPROGRAM_H


class academicProgram
{
public:
    academicProgram();
};

#endif // ACADEMICPROGRAM_H