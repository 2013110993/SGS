#include "coursesequence.h"

courseSequence::courseSequence()
{

}
