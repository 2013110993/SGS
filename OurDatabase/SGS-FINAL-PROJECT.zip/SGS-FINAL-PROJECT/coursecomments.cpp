#include "coursecomments.h"

courseComments::courseComments()
{

}
