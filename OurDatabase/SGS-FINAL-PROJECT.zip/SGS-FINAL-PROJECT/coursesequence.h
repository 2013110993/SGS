#ifndef COURSESEQUENCE_H
#define COURSESEQUENCE_H


class courseSequence
{
public:
    courseSequence();
};

#endif // COURSESEQUENCE_H