#include "academicprogram.h"

academicProgram::academicProgram()
{

}
