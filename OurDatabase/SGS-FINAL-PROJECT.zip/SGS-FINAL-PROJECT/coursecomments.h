#ifndef COURSECOMMENTS_H
#define COURSECOMMENTS_H


class courseComments
{
public:
    courseComments();
};

#endif // COURSECOMMENTS_H