#ifndef COURSES_H
#define COURSES_H


class courses
{
public:
    courses();
};

#endif // COURSES_H